import React, { useEffect, useRef, useState } from "react";
import "./app.css";

export default function App() {
  const [isListening, setIsListening] = useState(false);
  const [spokenText, setSpokenText] = useState("");
  const [interim, setInterim] = useState("");
  const [translated, setTranslated] = useState("");
  const [error, setError] = useState("");
  const [selectedPair, setSelectedPair] = useState("en|hi");
  const [voices, setVoices] = useState([]);

useEffect(() => {
  const loadVoices = () => {
    const allVoices = window.speechSynthesis.getVoices();
    setVoices(allVoices);
  };

  loadVoices();
  window.speechSynthesis.onvoiceschanged = loadVoices;
}, []);
  const recognitionRef = useRef(null);
  const lastProcessedRef = useRef("");

  /* LANGUAGE CONFIG: sourceLang (for SpeechRecognition) and targetLang (for TTS) */
  const languageMap = {
    "en|hi": { label: "English → Hindi", source: "en-US", target: "hi-IN", flags: "🇬🇧 → 🇮🇳" },
    "hi|en": { label: "Hindi → English", source: "hi-IN", target: "en-US", flags: "🇮🇳 → 🇬🇧" },
    "hi|ar": { label: "Hindi → Arabic", source: "hi-IN", target: "ar-SA", flags: "🇮🇳 → 🇸🇦" },
    "ar|hi": { label: "Arabic → Hindi", source: "ar-SA", target: "hi-IN", flags: "🇸🇦 → 🇮🇳" },
    "en|ar": { label: "English → Arabic", source: "en-US", target: "ar-SA", flags: "🇬🇧 → 🇸🇦" },
    "ar|en": { label: "Arabic → English", source: "ar-SA", target: "en-US", flags: "🇸🇦 → 🇬🇧" }
  };

  const current = languageMap[selectedPair];

  /* TRANSLATION using MyMemory (free) */
  const translateText = async (text) => {
    if (!text || !text.trim()) return;
    try {
      setError("");
      setTranslated((prev) => prev + " "); // spacing
      const res = await fetch(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
          text
        )}&langpair=${selectedPair}`
      );
      const data = await res.json();
      if (data && data.responseData && data.responseData.translatedText) {
        setTranslated((prev) => prev + data.responseData.translatedText + " ");
      } else {
        setError("Translation returned no result.");
      }
    } catch (e) {
      setError("Translation failed. Check connection.");
    }
  };

  /* START SPEECH RECOGNITION */
  const startListening = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setError("Speech Recognition not supported in this browser.");
      return;
    }

    setError("");
    const recog = new SR();
    recognitionRef.current = recog;

    recog.lang = current.source;
    recog.interimResults = true;
    recog.continuous = true;

    recog.onresult = (event) => {
      let final = "";
      let interimResult = "";

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript + " ";
        } else {
          interimResult += transcript;
        }
      }

      setInterim(interimResult);

      if (final.trim() && final.trim() !== lastProcessedRef.current) {
        lastProcessedRef.current = final.trim();
        setSpokenText((prev) => prev + final);
        translateText(final.trim());

        // reset after short delay to allow same phrase again later
        setTimeout(() => {
          lastProcessedRef.current = "";
        }, 900);
      }
    };

    recog.onerror = (e) => {
      if (e && e.error === "not-allowed") {
        setError("Microphone permission blocked.");
      } else {
        setError("Speech recognition error.");
      }
    };

    recog.onend = () => {
      // when browser auto-stops (mobile, or permission end), update state
      setIsListening(false);
    };

    try {
      recog.start();
      setIsListening(true);
    } catch (e) {
      setError("Failed to start microphone. Try refreshing and giving permission.");
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
    setInterim("");
    setIsListening(false);
  };

  const toggleMic = () => {
    if (isListening) stopListening();
    else startListening();
  };

  const clearAll = () => {
    stopListening();
    setSpokenText("");
    setInterim("");
    setTranslated("");
    setError("");
  };

  /* PLAY translated text using SpeechSynthesis */
  const playTranslated = () => {
  if (!translated || !translated.trim()) {
    setError("No translated text to play.");
    return;
  }

  try {
    window.speechSynthesis.cancel();

    const utter = new SpeechSynthesisUtterance(translated);
    utter.lang = current.target;
    utter.rate = 0.95;

    // FIX → find matching voice for Arabic / Hindi / English
    const voice = voices.find(
      (v) =>
        v.lang.toLowerCase().includes(current.target.toLowerCase().split("-")[0])
    );

    if (voice) {
      utter.voice = voice;   // SET THE VOICE
    } else {
      console.warn("No matching voice found for:", current.target);
    }

    window.speechSynthesis.speak(utter);
  } catch (e) {
    setError("Speech synthesis failed.");
  }
};


  /* When user changes language pair, stop recognition and clear texts */
  const handlePairChange = (e) => {
    const v = e.target.value;
    setSelectedPair(v);
    clearAll();
  };

  useEffect(() => {
    // cleanup on unmount
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      window.speechSynthesis.cancel();
    };
  }, []);

  return (
    <div id="root">
      {/* background blobs */}
      <div
        className="blob"
        style={{
          width: "320px",
          height: "320px",
          top: "-90px",
          left: "-80px",
          background: "#b362ff"
        }}
      />
      <div
        className="blob"
        style={{
          width: "360px",
          height: "360px",
          bottom: "-110px",
          right: "-80px",
          background: "#00e5ff"
        }}
      />

      <header>
        <h1>Neon Voice Translator</h1>
        <p className="small">Speak — translate — listen. Fast, offline-friendly demo.</p>
      </header>

      {error && <div className="error-box">{error}</div>}

      {/* language selector */}
      <div className="card">
        <h2 style={{ marginBottom: "0.5rem" }}>Choose Language Pair</h2>
        <select value={selectedPair} onChange={handlePairChange}>
          {Object.keys(languageMap).map((k) => (
            <option key={k} value={k}>
              {languageMap[k].flags} &nbsp; {languageMap[k].label}
            </option>
          ))}
        </select>
      </div>

      {/* controls */}
      <div className="card controls">
        <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <button
            className={isListening ? "stop" : "record"}
            onClick={toggleMic}
            aria-pressed={isListening}
          >
            {isListening ? "Stop Recording" : "Start Recording"}
          </button>

          <button className="clear" onClick={clearAll}>
            Clear
          </button>
        </div>

        <div style={{ marginLeft: "auto" }}>
          <div className="small">Current: {current.flags}</div>
        </div>
      </div>

      <div className="row">
        {/* Source / Detected speech */}
        <div>
          <div className="card">
            <h2>Detected Speech</h2>
            <div className="text-box">
              <div style={{ minHeight: "80px" }}>{spokenText}</div>
              <div style={{ color: "rgba(255,255,255,0.6)", marginTop: "6px" }}>{interim}</div>
            </div>
            <div style={{ marginTop: "0.75rem", display: "flex", gap: "0.5rem" }}>
              <button
                className="play"
                onClick={() => {
                  if (!spokenText.trim()) {
                    setError("No detected speech to play.");
                    return;
                  }
                  try {
                    window.speechSynthesis.cancel();
                    const ut = new SpeechSynthesisUtterance(spokenText);
                    ut.lang = current.source;
                    ut.rate = 0.95;
                    window.speechSynthesis.speak(ut);
                  } catch {
                    setError("Unable to play detected speech.");
                  }
                }}
              >
                Play Detected
              </button>
              <div style={{ alignSelf: "center", color: "var(--text-secondary)" }}>Detected language: {current.source}</div>
            </div>
          </div>
        </div>

        {/* Translated text */}
        <div>
          <div className="card">
            <h2>Translated Output</h2>
            <div className="text-box">{translated || <span style={{ color: "rgba(255,255,255,0.35)" }}>Translation will appear here…</span>}</div>
            <div style={{ marginTop: "0.75rem", display: "flex", gap: "0.5rem" }}>
              <button className="play" onClick={playTranslated}>
                Play Translation
              </button>
              <div style={{ alignSelf: "center", color: "var(--text-secondary)" }}>TTS language: {current.target}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
